export class tapType {
  single: boolean;

  constructor(numbersOfTap: boolean) {
    this.single = numbersOfTap;

  }
}
